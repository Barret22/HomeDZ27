import React from 'react';

const Contacts = () => {
    return (
        <div>
            <h2>Контакти</h2>
            <p>Тут мои контакти...</p>
        </div>
    );
};

export default Contacts;
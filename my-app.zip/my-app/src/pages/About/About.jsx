import React from 'react';

const About = () => {
    return (
        <div>
            <h2>Про мене</h2>
            <p>Тут інформація про мене...</p>
        </div>
    );
};

export default About;